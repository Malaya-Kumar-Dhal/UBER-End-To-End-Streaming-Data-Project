# Databricks notebook source
# MAGIC %sql
# MAGIC select * from uber.bronze.stg_rides

# COMMAND ----------

# MAGIC %md
# MAGIC ### STREAM RIDES TRANSFORMATION

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

rides_schema = StructType([StructField('ride_id', StringType(), True), StructField('confirmation_number', StringType(), True), StructField('passenger_id', StringType(), True), StructField('driver_id', StringType(), True), StructField('vehicle_id', StringType(), True), StructField('pickup_location_id', StringType(), True), StructField('dropoff_location_id', StringType(), True), StructField('vehicle_type_id', LongType(), True), StructField('vehicle_make_id', LongType(), True), StructField('payment_method_id', LongType(), True), StructField('ride_status_id', LongType(), True), StructField('pickup_city_id', LongType(), True), StructField('dropoff_city_id', LongType(), True), StructField('cancellation_reason_id', LongType(), True), StructField('passenger_name', StringType(), True), StructField('passenger_email', StringType(), True), StructField('passenger_phone', StringType(), True), StructField('driver_name', StringType(), True), StructField('driver_rating', DoubleType(), True), StructField('driver_phone', StringType(), True), StructField('driver_license', StringType(), True), StructField('vehicle_model', StringType(), True), StructField('vehicle_color', StringType(), True), StructField('license_plate', StringType(), True), StructField('pickup_address', StringType(), True), StructField('pickup_latitude', DoubleType(), True), StructField('pickup_longitude', DoubleType(), True), StructField('dropoff_address', StringType(), True), StructField('dropoff_latitude', DoubleType(), True), StructField('dropoff_longitude', DoubleType(), True), StructField('distance_miles', DoubleType(), True), StructField('duration_minutes', LongType(), True), StructField('booking_timestamp', TimestampType(), True), StructField('pickup_timestamp', StringType(), True), StructField('dropoff_timestamp', StringType(), True), StructField('base_fare', DoubleType(), True), StructField('distance_fare', DoubleType(), True), StructField('time_fare', DoubleType(), True), StructField('surge_multiplier', DoubleType(), True), StructField('subtotal', DoubleType(), True), StructField('tip_amount', DoubleType(), True), StructField('total_fare', DoubleType(), True), StructField('rating', DoubleType(), True)])

# COMMAND ----------

df = spark.read.table("uber.bronze.rides_raw")

df_parse = df.withColumn("parsed_rides", from_json(col("rides"), rides_schema)).select ("parsed_rides.*")

display(df_parse)


# COMMAND ----------

display(df)

# COMMAND ----------

df = spark.sql("select * from uber.bronze.bulk_rides")
df.schema

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from uber.bronze.stg_rides

# COMMAND ----------

# MAGIC %md
# MAGIC ## JINJA TEMPLATE FOR OBT

# COMMAND ----------

pip install Jinja2

# COMMAND ----------

jinja_config = [
    {
        "table": "uber.bronze.stg_rides AS stg_rides",
        "select": "stg_rides.vehicle_make_id",
        "where": ""
    },
    {
        "table": "uber.bronze.map_vehicle_makes AS map_vehicle_makes",
        "select": "map_vehicle_makes.vehicle_make",
        "where": "",
        "on": "stg_rides.vehicle_make_id = map_vehicle_makes.vehicle_make_id"
    },
    {
        "table": "uber.bronze.map_vehicle_types AS map_vehicle_types",
        "select": "map_vehicle_types.vehicle_type, map_vehicle_types.description, map_vehicle_types.base_rate, map_vehicle_types.per_mile, map_vehicle_types.per_minute",
        "where": "",
        "on": "stg_rides.vehicle_type_id = map_vehicle_types.vehicle_type_id"
    }
]

# COMMAND ----------

from jinja2 import Template


jinja_str = """


select
{% for config in jinja_config %}
{{ config.select }}
{% if not loop.last %}
,
{% endif %}
{% endfor %}

from
{% for config in jinja_config %}
{% if loop.first %}
{{ config.table }}
{% else %}
left join {{ config.table }} on {{ config.on }}
{% endif %}
{% endfor %}


{% for config in jinja_config %}
{% if loop.first %}
{% if config.where != "" %}
where
{% endif %}
{% endif %}


{{ config.where }}
{% if not loop.last %}
{% if config.where != "" %}
and
{% endif %}
{% endif %}


{% endfor %}


"""


template = Template(jinja_str)
rendered_template = template.render(jinja_config=jinja_config)
print(rendered_template)

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT 
# MAGIC     stg_rides.*,
# MAGIC     map_vehicle_makes.vehicle_make,
# MAGIC     map_vehicle_types.vehicle_type,
# MAGIC     map_vehicle_types.description,
# MAGIC     map_vehicle_types.base_rate,
# MAGIC     map_vehicle_types.per_mile,
# MAGIC     map_vehicle_types.per_minute
# MAGIC FROM uber.bronze.stg_rides AS stg_rides
# MAGIC
# MAGIC LEFT JOIN uber.bronze.map_vehicle_types AS map_vehicle_types
# MAGIC     ON stg_rides.vehicle_type_id = map_vehicle_types.vehicle_type_id
# MAGIC
# MAGIC LEFT JOIN uber.bronze.map_vehicle_makes AS map_vehicle_makes
# MAGIC     ON stg_rides.vehicle_make_id = map_vehicle_makes.vehicle_make_id;

# COMMAND ----------

display(spark.sql(rendered_template))

# COMMAND ----------

# MAGIC %pip install Jinja2

# COMMAND ----------

from jinja2 import Template
template = Template(jinja_str)
rendered_template = template.render(jinja_config=jinja_config)
display(spark.sql(rendered_template))

# COMMAND ----------

# MAGIC %sql
# MAGIC select current_timestamp()

# COMMAND ----------

# MAGIC %sql
# MAGIC drop table uber.bronze.stg_rides

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE TABLE uber.bronze.stg_rides;

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from uber.bronze.stg_rides

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from uber.bronze.silver_obt

# COMMAND ----------

df = spark.read.table("uber.bronze.silver_obt")
df = df.select("pickup_city_id","pickup_city", "city_updated_at","region","pickup_address","pickup_latitude","pickup_longitude","state","pickup_location_id")
df = df.dropDuplicates(subset=['pickup_location_id'])
display(df)

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from uber.bronze.dim_location

# COMMAND ----------

df = spark.read.table("uber.bronze.silver_obt")
df = df.select("distance_miles","duration_minutes","time_fare","base_fare","distance_fare","surge_multiplier","total_fare","tip_amount","rating","base_rate","per_mile","per_minute")
df = df.dropDuplicates(subset=['ride_id'])

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from uber.bronze.fact

# COMMAND ----------

# MAGIC %sql
# MAGIC select fact.ride_id, fact.base_fare, dim.region from uber.bronze.fact as fact
# MAGIC left join
# MAGIC uber.bronze.dim_location dim
# MAGIC on
# MAGIC fact.pickup_city_id = dim.pickup_city_id
# MAGIC and dim.`__END_AT` is null

# COMMAND ----------

