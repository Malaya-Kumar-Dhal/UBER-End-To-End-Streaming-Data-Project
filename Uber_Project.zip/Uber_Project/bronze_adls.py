# Databricks notebook source
import pandas as pd

df = pd.read_json("https://uberstorageaccountmkd.blob.core.windows.net/raw/ingestion/map_cities.json?sp=r&st=2026-08-12T01:31:26Z&se=2026-08-20T09:46:26Z&spr=https&sv=2026-02-06&sr=c&sig=vjtgU%2FVTlLxHPDuv92y8AHTAazWb9xKGbIj9LRUfWh8%3D")

df_spark = spark.createDataFrame(df)

display(df_spark)

# COMMAND ----------

import pandas as pd

for file in files:
    print(f"Reading: {file['file']}")

    url = f"https://uberstorageaccountmkd.blob.core.windows.net/raw/ingestion/{file['file']}.json?sp=r&st=2026-08-12T01:31:26Z&se=2026-08-20T09:46:26Z&spr=https&sv=2026-02-06&sr=c&sig=vjtgU%2FVTlLxHPDuv92y8AHTAazWb9xKGbIj9LRUfWh8%3D"

    try:
        df = pd.read_json(url)
        print(f"SUCCESS: {file['file']}")
    except Exception as e:
        print(f"FAILED: {file['file']}")
        print(e)

# COMMAND ----------

import pandas as pd




files = [
{"file":"map_cities"},
{"file":"map_cancellation_reasons"},
{"file":"bulk_rides"},
{"file":"map_payment_methods"},
{"file":"map_ride_statuses"},
{"file":"map_vehicle_makes"},
{"file":"map_vehicle_types"}
]




for file in files:

    url = f"https://uberstorageaccountmkd.blob.core.windows.net/raw/ingestion/{file['file']}.json?sp=r&st=2026-08-12T01:31:26Z&se=2026-08-20T09:46:26Z&spr=https&sv=2026-02-06&sr=c&sig=vjtgU%2FVTlLxHPDuv92y8AHTAazWb9xKGbIj9LRUfWh8%3D"


    df = pd.read_json(url)
    df_spark = spark.createDataFrame(df)
    df_spark.write.format("delta")\
        .mode("overwrite")\
        .option("overwriteSchema", "true")\
        .saveAsTable(f"uber.bronze.{file['file']}")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from uber.bronze.map_cities

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from uber.bronze.bulk_rides

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from uber.bronze.rides_raw

# COMMAND ----------

url = f"https://uberstorageaccountmkd.blob.core.windows.net/raw/ingestion/{file['file']}.json?sp=r&st=2026-08-12T01:31:26Z&se=2026-08-20T09:46:26Z&spr=https&sv=2026-02-06&sr=c&sig=vjtgU%2FVTlLxHPDuv92y8AHTAazWb9xKGbIj9LRUfWh8%3D"


df = pd.read_json(url)
df_spark = spark.createDataFrame(df)
    if not spark.catalog.tableExists("uber.bronze.bulk_rides")
    df_spark.write.format("delta")\
        .mode("overwrite")\
        .saveAsTable(f"uber.bronze.bulk_rides")
    print("This will not run more than 1 time")

# COMMAND ----------

