from pyspark import pipelines as dp
import pyspark.sql.types as T
from pyspark.sql.functions import *

rides_schema = T.StructType([
    T.StructField("ride_id", T.StringType(), True),
    T.StructField("confirmation_number", T.StringType(), True),
    T.StructField("passenger_id", T.StringType(), True),
    T.StructField("driver_id", T.StringType(), True),
    T.StructField("vehicle_id", T.StringType(), True),
    T.StructField("pickup_location_id", T.StringType(), True),
    T.StructField("dropoff_location_id", T.StringType(), True),
    T.StructField("vehicle_type_id", T.LongType(), True),
    T.StructField("vehicle_make_id", T.LongType(), True),
    T.StructField("payment_method_id", T.LongType(), True),
    T.StructField("ride_status_id", T.LongType(), True),
    T.StructField("pickup_city_id", T.LongType(), True),
    T.StructField("dropoff_city_id", T.LongType(), True),
    T.StructField("cancellation_reason_id", T.LongType(), True),
    T.StructField("passenger_name", T.StringType(), True),
    T.StructField("passenger_email", T.StringType(), True),
    T.StructField("passenger_phone", T.StringType(), True),
    T.StructField("driver_name", T.StringType(), True),
    T.StructField("driver_rating", T.DoubleType(), True),
    T.StructField("driver_phone", T.StringType(), True),
    T.StructField("driver_license", T.StringType(), True),
    T.StructField("vehicle_model", T.StringType(), True),
    T.StructField("vehicle_color", T.StringType(), True),
    T.StructField("license_plate", T.StringType(), True),
    T.StructField("pickup_address", T.StringType(), True),
    T.StructField("pickup_latitude", T.DoubleType(), True),
    T.StructField("pickup_longitude", T.DoubleType(), True),
    T.StructField("dropoff_address", T.StringType(), True),
    T.StructField("dropoff_latitude", T.DoubleType(), True),
    T.StructField("dropoff_longitude", T.DoubleType(), True),
    T.StructField("distance_miles", T.DoubleType(), True),
    T.StructField("duration_minutes", T.LongType(), True),
    T.StructField("booking_timestamp", T.TimestampType(), True),
    T.StructField("pickup_timestamp", T.StringType(), True),
    T.StructField("dropoff_timestamp", T.StringType(), True),
    T.StructField("base_fare", T.DoubleType(), True),
    T.StructField("distance_fare", T.DoubleType(), True),
    T.StructField("time_fare", T.DoubleType(), True),
    T.StructField("surge_multiplier", T.DoubleType(), True),
    T.StructField("subtotal", T.DoubleType(), True),
    T.StructField("tip_amount", T.DoubleType(), True),
    T.StructField("total_fare", T.DoubleType(), True),
    T.StructField("rating", T.DoubleType(), True)
])


dp.create_streaming_table("stg_rides")


@dp.append_flow(
    target="stg_rides"
)
def rides_bulk():
    df = spark.readStream.table("bulk_rides")
    df = df.withColumn("booking_timestamp", col("booking_timestamp").cast("timestamp"))
    return df


@dp.append_flow(
    target="stg_rides"
)
def rides_stream():
    df = spark.readStream.table("rides_raw")

    df_parse = (
        df
        .withColumn(
            "parsed_rides",
            from_json(col("rides"), rides_schema)
        )
        .select("parsed_rides.*")
    )

    return df_parse