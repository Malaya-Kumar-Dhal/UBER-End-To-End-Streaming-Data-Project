# Databricks notebook source
# /// script
# [tool.databricks.environment]
# environment_version = "5"
# ///

import pyspark.sql.types as T
from pyspark.sql.functions import *

# Event Hubs configuration
EH_NAMESPACE                    = "uberevents45"
EH_NAME                         = "ubertopic"

EH_CONN_STR                     = "Endpoint=sb://uberevents45.servicebus.windows.net/;SharedAccessKeyName=ListenPolicy;SharedAccessKey=SMHAFFSZW0W2LZnyyX1pr6d/q/ZA9GOoi+AEhDcMfj0=;EntityPath=ubertopic"
# Kafka Consumer configuration

KAFKA_OPTIONS = {
  "kafka.bootstrap.servers"  : f"{EH_NAMESPACE}.servicebus.windows.net:9093",
  "subscribe"                : EH_NAME,
  "kafka.sasl.mechanism"     : "PLAIN",
  "kafka.security.protocol"  : "SASL_SSL",
  "kafka.sasl.jaas.config"   : f"kafkashaded.org.apache.kafka.common.security.plain.PlainLoginModule required username=\"$ConnectionString\" password=\"{EH_CONN_STR}\";",
  "kafka.request.timeout.ms" : 10000,
  "kafka.session.timeout.ms" : 10000,
  "maxOffsetsPerTrigger"     : 10000,
  "failOnDataLoss"           : 'true',
  "startingOffsets"          : 'earliest'}

df = spark.readStream.format("kafka")\
    .options(**KAFKA_OPTIONS)\
    .load()



display(df, checkpointLocation = "/Volumes/uber/bronze/my_vol/volume_folder/")


# COMMAND ----------

